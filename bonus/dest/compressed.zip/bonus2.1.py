password = input("Enter password:")

while password != "pass123":
    psaaword = input("Enter password:")

    print("Password was correct!")
